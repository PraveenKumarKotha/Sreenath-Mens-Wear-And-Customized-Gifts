<?php
// Start the session and check if the user is logged in
session_start();

// Logout Logic
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: pages/login.php");
    exit();
}

// Database connection
include 'includes/db.php';

// Check if the user is logged in
$user_logged_in = isset($_SESSION['user_id']);
$user_name = "";

if ($user_logged_in) {
    // Fetch user details
    $stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $user_name = htmlspecialchars($user['username']);
    }
}

// Fetch products from the database
$stmt = $conn->query("SELECT * FROM products");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Store</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        /* Header Styling */
        .header-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #333;
            padding: 15px;
            color: white;
            text-align: center;
        }

        /* Shop Name Styling */
        .shop-name {
            font-size: 2.5em;
            font-weight: bold;
            background: linear-gradient(45deg, #FFD700, #FF6347, #00FFFF, #FF69B4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 2px 2px 5px rgba(255, 255, 255, 0.3);
            margin-bottom: 5px;
        }

        .shop-location {
            display: flex;
            align-items: center;
            gap: 30px;
            font-size: 1.5em;
            font-style: italic;
        }

        .shop-location a {
            color: #4CAF50;
            text-decoration: none;
            font-weight: bold;
        }

        .shop-location a:hover {
            text-decoration: underline;
        }

        /* Product Grid */
        .product-list {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 70px;
            padding: 20px;
            max-width: 1200px;
            margin: auto;
        }

        .product {
            background-color: #fff;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            width: 90%;
            margin: auto;
        }

        /* Ensure Product Image Fills the Space */
        .product img {
            width: 100%;
            height: 260px;
            object-fit: cover;
            border-radius: 5px;
        }

        /* Lightbox (Popup Zoom) */
        .lightbox {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .lightbox img {
            max-width: 80%;
            max-height: 80%;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.5);
        }

        /* Spacing between sizes and add to cart button */
        .size-options {
            margin-bottom: 15px;
        }
        .logout-button {
    background-color: #ff4d4d;
    color: white;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 5px;
}
.logout-button:hover {
    background-color: #cc0000;
}


        /* Responsive Design */
        @media (max-width: 768px) {
            .product-list {
                grid-template-columns: 1fr;
            }

            .product {
                width: 100%;
            }

            .product img {
                height: 200px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <h1 class="shop-name">Sreenath Mens Wear and Customized Gifts</h1>
            <p class="shop-location">
                <a href="https://www.google.com/maps/place/Sreenath+men's+wear/@14.41519,77.7199017,17z/data=!3m1!4b1!4m6!3m5!1s0x3bb14397593e343b:0x42e05cb94e48a711!8m2!3d14.41519!4d77.7199017!16s%2Fg%2F11sv5k4j1t?entry=ttu&g_ep=EgoyMDI1MDMxOS4yIKXMDSoJLDEwMjExNDU1SAFQAw%3D%3D" target="_blank">
                    <i class="fas fa-map-marker-alt"></i> Located at Dharmavaram
                </a>
                <a href="https://www.instagram.com/sreenath_customized_gifts?igsh=bHNlMGF4cmpmNXF0b" target="_blank">
                    <i class="fab fa-instagram"></i>
                </a>
            </p>
            <nav>
                <?php if ($user_logged_in) : ?>
                    <span class="user-greeting">Hello, <?= $user_name; ?>!</span>
                    <a href="pages/cart.php" class="cart-link">
                        <img src="images/cart-icon.png" alt="Cart" class="cart-icon"> Cart
                    </a>
                    <a href="pages/order_pending.php">My Orders</a>
                    <form method="POST" style="display: inline;">
                        <button type="submit" name="logout" class="logout-button">Logout</button>
                    </form>
                <?php else : ?>
                    <a href="pages/login.php">Login</a>
                    <a href="pages/register.php">Register</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <div class="main-container">
        <main>
            <h2>Products</h2>
            <div class="product-list">
                <?php if (empty($products)) : ?>
                    <p>No products available.</p>
                <?php else : ?>
                    <?php foreach ($products as $product) : ?>
                        <div class="product">
                            <h3><?= htmlspecialchars($product['name']); ?></h3>
                            <p>Price: Rs.<?= number_format($product['price'], 2); ?></p>
                            <p><?= htmlspecialchars($product['description']); ?></p>
                            <?php if (!empty($product['image'])) : ?>
                                <img src="images/<?= htmlspecialchars($product['image']); ?>" 
                                     alt="<?= htmlspecialchars($product['name']); ?>" 
                                     class="product-image"
                                     onclick="openLightbox(this)">
                            <?php endif; ?>
                            
                            <!-- Size Selection -->
                            <form method="POST" action="pages/cart.php">
                                <input type="hidden" name="product_id" value="<?= $product['id']; ?>">
                                <p>Select Size:</p>
                                <div class="size-options">
                                    <?php 
                                    $sizes = explode(',', $product['sizes']); 
                                    foreach ($sizes as $size) : ?>
                                        <label>
                                            <input type="radio" name="size" value="<?= trim($size); ?>" required> <?= trim($size); ?>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                                <button type="submit" name="add_to_cart" class="add-to-cart-button">Add to Cart</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <footer>
        <p>&copy; <?= date('Y'); ?> Online Store. All rights reserved.</p>
    </footer>

    <script>
        function openLightbox(img) {
            document.getElementById("lightbox-img").src = img.src;
            document.getElementById("lightbox").style.display = "flex";
        }

        function closeLightbox() {
            document.getElementById("lightbox").style.display = "none";
        }

        document.addEventListener("keydown", function(event) {
            if (event.key === "Escape") {
                closeLightbox();
            }
        });
    </script>
    <div id="lightbox" class="lightbox" onclick="closeLightbox()">
    <img id="lightbox-img" src="" alt="Zoomed Image">
</div>

</body>
</html>
