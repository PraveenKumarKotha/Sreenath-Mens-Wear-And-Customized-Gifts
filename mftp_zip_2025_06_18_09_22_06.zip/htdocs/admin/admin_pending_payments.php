<?php
require '../includes/phpmailer/PHPMailer.php';
require '../includes/phpmailer/SMTP.php';
require '../includes/phpmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
session_start();
include '../includes/db.php'; // Ensure correct database connection

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Fetch all pending payments (including transaction ID)
$stmt = $conn->prepare("
    SELECT p.id, p.order_id, p.transaction_id, p.amount, p.payment_method, p.status, o.payment_status 
    FROM payments p 
    JOIN orders o ON p.order_id = o.id 
    WHERE p.status = 'PENDING' AND o.payment_status = 'PENDING'
");
$stmt->execute();
$pending_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Approve or Reject Payment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['payment_id'], $_POST['action'])) {
    $payment_id = $_POST['payment_id'];
    $action = $_POST['action'];

    $status = ($action === 'approve') ? 'SUCCESS' : 'FAILED';

    try {
        // Fetch the order ID linked to this payment
        $fetch_order = $conn->prepare("SELECT order_id FROM payments WHERE id = ?");
        $fetch_order->execute([$payment_id]);
        $order = $fetch_order->fetch(PDO::FETCH_ASSOC);

        if ($order) {
            $order_id = $order['order_id'];

            // Update payment status
            $update_stmt = $conn->prepare("UPDATE payments SET status = ? WHERE id = ?");
            $update_stmt->execute([$status, $payment_id]);

            // Update order payment status
            $update_order = $conn->prepare("UPDATE orders SET payment_status = ? WHERE id = ?");
            $update_order->execute([$status, $order_id]);

            // Fetch user email and name
$user_stmt = $conn->prepare("
SELECT u.email, u.username 
FROM users u 
JOIN orders o ON o.user_id = u.id 
WHERE o.id = ?
");
$user_stmt->execute([$order_id]);
$user = $user_stmt->fetch(PDO::FETCH_ASSOC);
// Fetch payment details for transaction ID and amount
$payment_details_stmt = $conn->prepare("SELECT transaction_id, amount FROM payments WHERE id = ?");
$payment_details_stmt->execute([$payment_id]);
$payment = $payment_details_stmt->fetch(PDO::FETCH_ASSOC); // this $payment now holds correct data
if ($user) {

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';  
            $mail->SMTPAuth = true;
            $mail->Username = 'sreenathmenswear7@gmail.com'; 
            $mail->Password = 'vdew lvzm qvte pdim';     
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            // Email content
            $mail->setFrom('sreenathmenswear7@gmail.com', 'Sreenath Mens Wear And Customized Gifts'); // ✅ Your sender details
    $mail->addAddress($user['email'], $user['username']);

    $mail->isHTML(true);

    if ($status === 'SUCCESS') {
        $mail->Subject = '✅ Order Confirmed - Thank you for your purchase!';
        $mail->Body    = "Dear <strong>{$user['username']}</strong>,<br><br>Your payment (Transaction ID: <strong>{$payment['transaction_id']}</strong>) has been <strong>approved</strong> and your order is being processed.<br><br>Thank you for shopping with us!";
    } else {
        $mail->Subject = '❌ Order Failed - Payment Rejected';
        $mail->Body    = "Dear <strong>{$user['username']}</strong>,<br><br>Unfortunately, your payment (Transaction ID: <strong>{$payment['transaction_id']}</strong>) was <strong>rejected</strong>.<br>Please try again or contact support if you believe this was a mistake.";
    }

    $mail->send();
} catch (Exception $e) {
    // Optional: Log or display mail sending error
}
}

// Redirect after processing
echo "<script>alert('Payment $status successfully!'); window.location.href = 'http://sreenathmenswearandcustomizedgifts.fwh.is/admin/process_payment.php';</script>";
exit();

        } else {
            echo "<script>alert('Error: Order not found for this payment!');</script>";
        }
    } catch (PDOException $e) {
        echo "<script>alert('Error processing payment: " . $e->getMessage() . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Pending Payments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 70%;
            margin: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        button {
            padding: 10px;
            border: none;
            cursor: pointer;
            font-weight: bold;
            font-size: 14px;
            margin-top: 5px;
            width: 100%;
        }
        .approve {
            background-color: #28a745;
            color: white;
            border-radius: 5px;
        }
        .reject {
            background-color: #dc3545;
            color: white;
            border-radius: 5px;
        }
        .reject:hover {
            background-color: #c82333;
        }
        .btn-back {
            display: block;
            width: 160px;
            margin: 30px auto;
            padding: 12px;
            background-color: #007bff;
            color: white;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
        }
        .btn-back:hover {
            background-color: #0056b3;
        }

        /* Mobile-Friendly Enhancements */
        @media (max-width: 768px) {
            .container {
                width: 95%;
                padding: 15px;
            }
            table {
                display: block;
                width: 100%;
                overflow-x: auto;
                white-space: nowrap;
            }
            th, td {
                font-size: 14px;
                padding: 10px;
            }
            button {
                font-size: 13px;
                padding: 8px;
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Pending Payments</h2>
        <?php if (!empty($pending_payments)): ?>
            <table>
                <tr>
                    <th>Payment ID</th>
                    <th>Order ID</th>
                    <th>Transaction ID</th>
                    <th>Amount</th>
                    <th>Payment Method</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($pending_payments as $payment): ?>
                    <tr>
                        <td><?= htmlspecialchars($payment['id']) ?></td>
                        <td><?= htmlspecialchars($payment['order_id']) ?></td>
                        <td><?= htmlspecialchars($payment['transaction_id']) ?></td>
                        <td>₹<?= number_format($payment['amount'], 2) ?></td>
                        <td><?= htmlspecialchars(strtoupper($payment['payment_method'])) ?></td>
                        <td><?= htmlspecialchars($payment['status']) ?></td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="payment_id" value="<?= $payment['id'] ?>">
                                <button type="submit" name="action" value="approve" class="approve">✅ Approve</button>
                                <button type="submit" name="action" value="reject" class="reject">❌ Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p style="color: red;">No pending payments found.</p>
        <?php endif; ?>
        <a href="dashboard.php" class="btn-back">Back to Dashboard</a>
    </div>

</body>
</html>
