<?php
include '../includes/db.php';
require '../includes/phpmailer/PHPMailer.php';
require '../includes/phpmailer/SMTP.php';
require '../includes/phpmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];
    move_uploaded_file($_FILES['image']['tmp_name'], "../images/$image");

    $sizes = isset($_POST['sizes']) ? implode(",", $_POST['sizes']) : '';

    $stmt = $conn->prepare("INSERT INTO products (name, price, description, image, sizes) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $price, $description, $image, $sizes]);

    $product_id = $conn->lastInsertId();
    $product_name = $name;
    $product_description = $description;

    $successMessage = "Product added successfully!";

    // Fetch all verified user emails
    $stmt = $conn->prepare("SELECT email FROM users WHERE is_verified = 1");
    $stmt->execute();
    $emails = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Email details
    $subject = "New Product Alert: " . $product_name;
    $body = "
        <h3>Check out our new product!</h3>
        <p><strong>$product_name</strong></p>
        <p>$product_description</p>
        <p>Price: ₹$price</p>
        <a href='https://sreenathmenswearandcustomizedgifts.fwh.is/pages/product_details.php?id=$product_id'>View Product</a>
    ";

    foreach ($emails as $email) {
        $mail = new PHPMailer(true);
        try {

            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';  
            $mail->SMTPAuth = true;
            $mail->Username = 'sreenathmenswear7@gmail.com'; 
            $mail->Password = 'vdew lvzm qvte pdim';     
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            // Email content
            $mail->setFrom('sreenathmenswear7@gmail.com', 'Sreenath Mens Wear And Customized Gifts');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $body;

            $mail->send();
        } catch (Exception $e) {
            error_log("Mailer Error for $email: " . $mail->ErrorInfo);

        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            font-weight: bold;
            color: #555;
        }
        input[type="text"],
        input[type="number"],
        textarea,
        input[type="file"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        textarea {
            resize: vertical;
            height: 100px;
        }
        .sizes label {
            margin-right: 10px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #45a049;
        }
        .message {
            color: green;
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
        }
       .btn-back {
            display: block;
            width: 160px;
            margin: 30px auto;
            padding: 12px;
            background-color: #007bff;
            color: white;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
        }
        .btn-back:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Add Product</h2>
    <form method="POST" enctype="multipart/form-data">
        <label for="name">Product Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="price">Price:</label>
        <input type="number" step="0.01" name="price" id="price" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description" required></textarea>

        <label for="image">Image:</label>
        <input type="file" name="image" id="image" required>

        <label style="display: block; margin-bottom: 10px;">Select Available Sizes:</label>
        <div class="sizes">
            <input type="checkbox" name="sizes[]" value="S"> S
            <input type="checkbox" name="sizes[]" value="M"> M
            <input type="checkbox" name="sizes[]" value="L"> L
            <input type="checkbox" name="sizes[]" value="XL"> XL
            <input type="checkbox" name="sizes[]" value="XXL"> XXL
            <input type="checkbox" name="sizes[]" value="Custom Size"> Custom Size
        </div>

        <button type="submit" name="add_product" style="margin-top: 15px;">Add Product</button>
    </form>

    <?php if (isset($successMessage)): ?>
        <div class="message"><?php echo $successMessage; ?></div>
    <?php endif; ?>

   <a href="dashboard.php" class="btn-back">Back to Dashboard</a>
</div>
</body>
</html>
