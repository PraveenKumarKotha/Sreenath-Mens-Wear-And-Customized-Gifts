<?php
include '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$stmt = $conn->query("SELECT * FROM products");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        .table-wrapper {
            overflow-x: auto; /* Enables horizontal scrolling */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            min-width: 600px; /* Prevents breaking in mobile */
        }
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #28a745;
            color: white;
        }
        td img {
            width: 50px;
            height: auto;
            border-radius: 5px;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .actions a {
            margin: 5px 5px;
            padding: 6px 10px;
            font-size: 14px;
            display: inline-block;
            color: #007bff;
            text-decoration: none;
            border: 1px solid #007bff;
            border-radius: 4px;
            transition: background-color 0.3s, color 0.3s;
        }
        .actions a:hover {
            background-color: #007bff;
            color: white;
        }
        .btn-back {
            display: block;
            width: 160px;
            margin: 30px auto;
            padding: 12px;
            background-color: #007bff;
            color: white;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
        }
        .btn-back:hover {
            background-color: #0056b3;
        }

        /* Mobile-Friendly Enhancements */
        @media (max-width: 768px) {
            .container {
                width: 95%;
                padding: 20px;
            }
            .actions a {
                display: block;
                width: 100%;
                text-align: center;
                margin: 5px 0;
            }
            td img {
                width: 40px;
            }
            table {
                font-size: 14px;
            }
            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Manage Products</h2>

    <div class="table-wrapper">
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Description</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>

            <?php foreach ($products as $product) : ?>
                <tr>
                    <td><?= $product['id']; ?></td>
                    <td><?= htmlspecialchars($product['name']); ?></td>
                    <td>Rs.<?= number_format($product['price'], 2); ?></td>
                    <td><?= htmlspecialchars($product['description']); ?></td>
                    <td><img src="../images/<?= htmlspecialchars($product['image']); ?>" alt="Product Image"></td>
                    <td class="actions">
                        <a href="edit_product.php?id=<?= $product['id']; ?>">Edit</a>
                        <a href="delete_product.php?id=<?= $product['id']; ?>" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>

        </table>
    </div>

    <a href="dashboard.php" class="btn-back">Back to Dashboard</a>
</div>

</body>
</html>
