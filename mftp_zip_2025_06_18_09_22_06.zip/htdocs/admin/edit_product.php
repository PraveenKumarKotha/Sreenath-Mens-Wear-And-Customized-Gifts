<?php
include '../includes/db.php';
require '../includes/phpmailer/PHPMailer.php';
require '../includes/phpmailer/SMTP.php';
require '../includes/phpmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

// Check if product ID is provided
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Fetch product details
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        header("Location: manage_products.php?error=Product not found");
        exit();
    }
} else {
    header("Location: manage_products.php?error=Invalid request");
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    // Check if a new image is uploaded
    if (!empty($_FILES['image']['name'])) {
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_path = "../images/" . $image_name;
        move_uploaded_file($image_tmp, $image_path);
    } else {
        $image_name = $product['image'];
    }

    // Update product details in the database
    $stmt = $conn->prepare("UPDATE products SET name = ?, price = ?, description = ?, image = ? WHERE id = ?");
    $stmt->execute([$name, $price, $description, $image_name, $product_id]);

    // Send email to verified users

    $product_name = $name;
    $product_description = $description;

    $stmt = $conn->prepare("SELECT email FROM users WHERE is_verified = 1");
    $stmt->execute();
    $emails = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $subject = "Product Updated: " . $product_name;
    $body = "
        <h3>We’ve updated a product you might love!</h3>
        <p><strong>$product_name</strong></p>
        <p>$product_description</p>
        <p>Price: ₹$price</p>
        <a href='https://sreenathmenswearandcustomizedgifts.fwh.is/pages/product_details.php?id=$product_id'>View Product</a>
    ";

    foreach ($emails as $email) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'sreenathmenswear7@gmail.com';
            $mail->Password   = 'vdew lvzm qvte pdim'; // App password
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            $mail->setFrom('sreenathmenswear7@gmail.com', 'Sreenath Mens Wear And Customized Gifts');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $body;

            $mail->send();
        } catch (Exception $e) {
            // Optional: log error
        }
    }

    header("Location: manage_products.php?success=Product updated successfully");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: #eef5e1;
            font-family: 'Poppins', sans-serif;
        }
        .container {
            max-width: 600px;
            background: #ffffff;
            padding: 30px;
            margin: 50px auto;
            border-radius: 12px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.15);
            border: 3px solid #8bc34a;
            animation: fadeIn 0.5s ease-in-out;
        }
        h2 {
            text-align: center;
            color: #388e3c;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .form-label {
            font-weight: 600;
            color: #388e3c;
        }
        img {
            display: block;
            margin: 15px auto;
            border-radius: 10px;
            max-width: 120px;
            box-shadow: 0px 2px 8px rgba(0, 0, 0, 0.2);
        }
        .btn-primary {
            background: #43a047;
            border: none;
            font-weight: bold;
            transition: 0.3s ease;
        }
        .btn-primary:hover {
            background: #2e7d32;
        }
        .btn-secondary {
            background: #444;
            border: none;
        }
        .btn-secondary:hover {
            background: #333;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Product</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Product Name</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($product['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Price (Rs)</label>
            <input type="number" name="price" class="form-control" value="<?= htmlspecialchars($product['price']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($product['description']) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Product Image</label>
            <input type="file" name="image" class="form-control">
            <img src="../images/<?= $product['image'] ?>" alt="Product Image">
        </div>

        <div class="text-center">
            <button type="submit" class="btn btn-primary">Update Product</button>
            <a href="manage_products.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
