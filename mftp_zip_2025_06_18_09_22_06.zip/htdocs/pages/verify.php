<?php
include('../includes/db.php');

if (isset($_GET['email']) && isset($_GET['token'])) {
    $email = $_GET['email'];
    $token = $_GET['token'];

    // Check if such user exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND token = ?");
    $stmt->execute([$email, $token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Update verification status
        $stmt = $conn->prepare("UPDATE users SET is_verified = 1, token = NULL WHERE email = ?");
        if ($stmt->execute([$email])) {
            echo "<h2>Email verified successfully!</h2><p><a href='login.php'>Click here to login</a></p>";
        } else {
            echo "<h2>Failed to update verification status.</h2>";
        }
    } else {
        echo "<h2>Invalid or expired verification link.</h2>";
    }
} else {
    echo "<h2>Invalid request!</h2>";
}
?>
