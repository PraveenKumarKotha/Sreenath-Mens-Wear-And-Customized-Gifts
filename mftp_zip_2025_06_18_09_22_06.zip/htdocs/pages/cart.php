<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

$user_id = $_SESSION['user_id']; // Ensure the correct user session is used

// Handle Add to Cart with Quantity and Size
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1; // Default to 1 if not set
    $size = $_POST['size']; // Get selected size

    // Check if product with same size is already in the user's cart
    $stmt = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ? AND size = ?");
    $stmt->execute([$user_id, $product_id, $size]);
    $cart_item = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($cart_item) {
        // Update quantity if the same product and size are already in the cart
        $new_quantity = $cart_item['quantity'] + $quantity;
        $stmt = $conn->prepare("UPDATE cart SET quantity = ?, updated_at = NOW() WHERE user_id = ? AND product_id = ? AND size = ?");
        $stmt->execute([$new_quantity, $user_id, $product_id, $size]);
    } else {
        // Add new product with size to the cart
        $stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, size, quantity, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())");
        $stmt->execute([$user_id, $product_id, $size, $quantity]);
    }
}

// Handle Product Removal from Cart
if (isset($_POST['remove_from_cart'])) {
    $product_id = $_POST['product_id'];
    $size = $_POST['size'];
    $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ? AND size = ?");
    $stmt->execute([$user_id, $product_id, $size]);
}

// Handle Quantity Update
if (isset($_POST['update_quantity'])) {
    $product_id = $_POST['product_id'];
    $size = $_POST['size'];
    $quantity = (int)$_POST['quantity'];

    // Update the quantity in the cart
    $stmt = $conn->prepare("UPDATE cart SET quantity = ?, updated_at = NOW() WHERE user_id = ? AND product_id = ? AND size = ?");
    $stmt->execute([$quantity, $user_id, $product_id, $size]);
}

// Fetch the user's cart items (Filter by user_id)
$stmt = $conn->prepare("SELECT c.*, p.name, p.price, p.image FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_cost = 0; // Initialize total cost variable
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            font-size: 2em;
            margin-bottom: 20px;
        }
        .cart-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }
        .cart-item img {
            max-width: 80px;
            border-radius: 8px;
            margin-right: 15px;
        }
        .item-details {
            flex-grow: 1;
            min-width: 150px;
        }
        .item-name {
            font-size: 1.1em;
            font-weight: bold;
            color: #343a40;
        }
        .item-price {
            font-size: 1em;
            color: #495057;
        }
        .item-size {
            font-size: 0.9em;
            color: #6c757d;
        }
        .item-actions {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .item-actions button, .item-actions form button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 6px 10px;
            margin: 5px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }
        .item-actions button:hover, .item-actions form button:hover {
            background-color: #0056b3;
        }
        .quantity {
            width: 50px;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1em;
        }
        .cart-actions {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }
        .cart-actions a {
            background-color: #28a745;
            color: white;
            padding: 10px 16px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 1em;
            transition: background-color 0.3s;
            text-align: center;
            display: block;
            margin: 5px;
        }
        .cart-actions a:hover {
            background-color: #218838;
        }
        .total-cost {
            font-size: 1.4em;
            font-weight: bold;
            color: #343a40;
            text-align: center;
            margin-top: 20px;
        }
        .empty-cart {
            text-align: center;
            font-size: 1.1em;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Your Cart</h2>
        <?php
        if (empty($cart_items)) {
            echo "<p class='empty-cart'>Your cart is empty.</p>";
        } else {
            foreach ($cart_items as $cart_item) {
                $total_cost += $cart_item['price'] * $cart_item['quantity'];

                echo "<div class='cart-item'>
                        <img src='../images/{$cart_item['image']}' alt='{$cart_item['name']}' class='item-image'>
                        <div class='item-details'>
                            <div class='item-name'>{$cart_item['name']}</div>
                            <div class='item-price'>Rs.{$cart_item['price']} x {$cart_item['quantity']}</div>
                            <div class='item-size'>Size: {$cart_item['size']}</div>
                        </div>
                        <div class='item-actions'>
                            <form method='POST'>
                                <input type='hidden' name='product_id' value='{$cart_item['product_id']}'>
                                <input type='hidden' name='size' value='{$cart_item['size']}'>
                                <input type='number' name='quantity' value='{$cart_item['quantity']}' class='quantity' min='1' required>
                                <button type='submit' name='update_quantity'>Update</button>
                            </form>
                            <form method='POST'>
                                <input type='hidden' name='product_id' value='{$cart_item['product_id']}'>
                                <input type='hidden' name='size' value='{$cart_item['size']}'>
                                <button type='submit' name='remove_from_cart'>Remove</button>
                            </form>
                        </div>
                      </div>";
            }
        }
        ?>
        <div class="total-cost">Total: Rs.<?= number_format($total_cost, 2); ?></div>
        <div class="cart-actions">
            <a href="../index.php">Back to Shop</a>
            <a href="checkout.php">Proceed to Checkout</a>
        </div>
    </div>
</body>
</html>
