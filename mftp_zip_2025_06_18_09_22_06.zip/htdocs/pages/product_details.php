<?php
include('../includes/db.php');
session_start();

if (!isset($_GET['id'])) {
    echo "Invalid Product ID!";
    exit;
}

$product_id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    echo "Product not found!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($product['name']); ?> | E-Commerce</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Quicksand', sans-serif;
            margin: 0;
            background: linear-gradient(to bottom right, #e0f7fa, #fce4ec);
        }

        .wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            background: #fff;
            display: grid;
            grid-template-columns: 1fr 1fr;
            max-width: 1200px;
            width: 100%;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            overflow: hidden;
            animation: fadeIn 0.8s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .image-box {
            background: #fafafa;
            padding: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .image-box img {
            max-width: 100%;
            max-height: 500px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            transition: transform 0.3s ease;
            cursor: zoom-in;
        }

        .image-box img:hover {
            transform: scale(1.05);
        }

        .details-box {
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .product-title {
            font-size: 36px;
            font-weight: 700;
            color: #6a1b9a;
            margin-bottom: 15px;
        }

        .brand {
            font-size: 18px;
            color: #888;
            margin-bottom: 20px;
        }

        .price {
            font-size: 30px;
            font-weight: bold;
            color: #2e7d32;
            margin-bottom: 20px;
        }

        .description {
            font-size: 17px;
            color: #555;
            margin-bottom: 30px;
            white-space: pre-wrap;
            line-height: 1.6;
        }

        .btn {
            padding: 14px 32px;
            font-size: 16px;
            font-weight: bold;
            color: white;
            border: none;
            border-radius: 10px;
            text-decoration: none;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .login-btn {
            background: linear-gradient(135deg, #007bff, #00c6ff);
        }

        .login-btn:hover {
            background: linear-gradient(135deg, #0056b3, #008cdd);
            transform: scale(1.05);
        }

        .store-btn {
            background: linear-gradient(135deg, #ff6a00, #ffb347);
        }

        .store-btn:hover {
            background: linear-gradient(135deg, #e65100, #ffa726);
            transform: scale(1.05);
        }

        @media (max-width: 768px) {
            .container {
                grid-template-columns: 1fr;
            }

            .details-box {
                padding: 25px;
            }

            .product-title {
                font-size: 28px;
            }

            .price {
                font-size: 24px;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="image-box">
                <?php
                $image = $product['image'];
                $image_path = '../images/' . $image;
                if (!empty($image) && file_exists($image_path)) {
                    echo "<img src='$image_path' alt='Product Image' onclick='zoomImage(this)'>";
                } else {
                    echo "<p><em>No image available.</em></p>";
                }
                ?>
            </div>
            <div class="details-box">
                <div class="product-title"><?= htmlspecialchars($product['name']); ?></div>
                <div class="brand">Sold by: Sreenath Mens Wear And Customized Gifts</div>
                <div class="price">₹<?= number_format($product['price'], 2); ?></div>
                <div class="description"><?= htmlspecialchars($product['description']); ?></div>

                <?php if (!isset($_SESSION['user_id'])): ?>
                    <a href="login.php" class="btn login-btn">Login to Visit Store</a>
                <?php else: ?>
                    <a href="https://sreenathmenswearandcustomizedgifts.fwh.is/index.php" class="btn store-btn">Visit Store</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal structure for zoom -->
<div id="zoomModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:9999; justify-content:center; align-items:center;">
    <img id="zoomedImage" src="" alt="Zoomed Image" style="max-width:90%; max-height:90%; border-radius:10px; box-shadow:0 0 20px rgba(0,0,0,0.5);">
</div>

<script>
    const zoomModal = document.getElementById("zoomModal");
    const zoomedImage = document.getElementById("zoomedImage");

    function zoomImage(img) {
        zoomedImage.src = img.src;
        zoomModal.style.display = "flex";
    }

    // Close on outside click
    zoomModal.addEventListener("click", function (e) {
        if (e.target === zoomModal) {
            zoomModal.style.display = "none";
        }
    });

    // Close on ESC key
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") {
            zoomModal.style.display = "none";
        }
    });
</script>

</body>
</html>
