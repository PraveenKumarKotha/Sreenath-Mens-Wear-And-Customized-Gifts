<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: checkout.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #ffe5b4, #fff5e1); /* Smooth Peach Gradient */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 30px;
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.15);
            border-radius: 12px;
            text-align: center;
            max-width: 400px;
            border: 2px solid #ffcc80;
        }
        h1 {
            color: #d9534f;
            font-size: 24px;
        }
        p {
            font-size: 18px;
            color: #555;
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 20px;
            font-size: 18px;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: 0.3s ease-in-out;
        }
        .retry {
            background: #f0ad4e;
        }
        .retry:hover {
            background: #ec971f;
        }
        .home {
            background: #007bff;
        }
        .home:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>⚠ Payment Failed</h1>
        <p>Oops! Your payment was not successful.</p>
        <p>Please try again or choose a different payment method.</p>

        <a href="payment.php" class="btn retry">🔄 Retry Payment</a>
        <a href="http://localhost/ecommerce/index.php" class="btn home">🏠 Go to Home</a>
    </div>
</body>
</html>
