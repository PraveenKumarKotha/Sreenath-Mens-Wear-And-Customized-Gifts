<?php
include('../includes/db.php');
require '../includes/phpmailer/PHPMailer.php';
require '../includes/phpmailer/SMTP.php';
require '../includes/phpmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();

if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'user';
    $token = bin2hex(random_bytes(16));

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $error_message = "Email is already registered!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role, token, is_verified) VALUES (?, ?, ?, ?, ?, 0)");
        $stmt->execute([$username, $email, $password, $role, $token]);

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'sreenathmenswear7@gmail.com';
            $mail->Password = 'vdew lvzm qvte pdim';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('sreenathmenswear7@gmail.com', 'Sreenath Mens Wear And Customized Gifts');
            $mail->addAddress($email, $username);

            $mail->isHTML(true);
            $mail->Subject = 'Verify Your Email';
            $mail->Body = "
                <h3>Hi $username,</h3>
                <p>Thank you for registering at Sreenath Mens Wear and Customized Gifts.</p>
                <p>Please click the link below to verify your email address:</p>
                <a href='https://sreenathmenswearandcustomizedgifts.fwh.is/pages/verify.php?email=$email&token=$token'>Verify Email</a>
                <p>Please Report Has Not Spam,Then New Mails Will be Recieved in Inbox</p>
                <p>If you did not register, please ignore this email.</p>
                <br><p>Regards,<br>Sreenath Mens Wear and Customized Gifts Team</p>
            ";

            $mail->send();
            $success_message = 'A verification email has been sent to your email address. Please check your <strong style="color:black;">Inbox</strong> or <strong style="color:black;">Spam folder</strong> and click the verification link to activate your account.';
        } catch (Exception $e) {
            $error_message = "Email could not be sent. Error: {$mail->ErrorInfo}";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .register-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        h2 { color: #333; margin-bottom: 20px; }
        label {
            font-size: 1.1em;
            margin-bottom: 5px;
            display: block;
            text-align: left;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%; padding: 10px; margin-bottom: 15px;
            border: 1px solid #ccc; border-radius: 5px; font-size: 1em;
        }
        button {
            width: 100%; padding: 12px;
            background-color: #28a745; color: white;
            font-size: 1.1em; border: none; border-radius: 5px;
            cursor: pointer; transition: background-color 0.3s;
        }
        button:hover { background-color: #218838; }
        .error-message, .success-message {
            margin-top: 10px; font-size: 1em;
        }
        .error-message { color: #e74c3c; }
        .success-message { color: #28a745; }
        .login-link { margin-top: 15px; font-size: 1em; }
        .login-link a { color: #007bff; text-decoration: none; }
        .login-link a:hover { text-decoration: underline; }
        .password-wrapper {
            position: relative;
        }
        .eye-icon {
            position: absolute;
            right: 10px;
            top: 0;
            bottom: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
            user-select: none;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Register</h2>
        <form method="POST" onsubmit="return checkPasswordsMatch();">
            <label>Username:</label>
            <input type="text" name="username" required>

            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Password:</label>
            <div class="password-wrapper">
                <input type="password" name="password" id="password" required>
                <span class="eye-icon" onclick="togglePassword('password', this)">👁️</span>
            </div>

            <label>Confirm Password:</label>
            <div class="password-wrapper">
                <input type="password" id="confirm_password" required>
                <span class="eye-icon" onclick="togglePassword('confirm_password', this)">👁️</span>
            </div>

            <button type="submit" name="register">Register</button>
        </form>

        <?php if (isset($error_message)): ?>
            <p class="error-message"><?= htmlspecialchars($error_message); ?></p>
        <?php elseif (isset($success_message)): ?>
            <p class="success-message"><?= $success_message; ?></p>
        <?php endif; ?>

        <p class="login-link">Already registered? <a href="login.php">Please login</a></p>
    </div>

    <script>
        function togglePassword(id, el) {
            const input = document.getElementById(id);
            if (input.type === "password") {
                input.type = "text";
                el.textContent = "🙈";
            } else {
                input.type = "password";
                el.textContent = "👁️";
            }
        }

        function checkPasswordsMatch() {
            const pass = document.getElementById("password").value;
            const confirm = document.getElementById("confirm_password").value;

            if (pass !== confirm) {
                alert("Passwords do not match!");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
