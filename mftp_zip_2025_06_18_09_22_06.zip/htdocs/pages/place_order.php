<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['checkout'])) {
    header("Location: checkout.php");
    exit();
}

$checkout_data = $_SESSION['checkout'];
$user_id = $_SESSION['user_id'];
$name = $checkout_data['name'];
$address = $checkout_data['address'];
$payment_method = $checkout_data['payment_method'];
$total_price = $checkout_data['total_price'];
$mobile = $checkout_data['mobile'];
$payment_status = isset($_POST['payment_status']) && $_POST['payment_status'] == "success" ? "SUCCESS" : "FAILED";

// Database Connection
$conn = new mysqli("localhost", "root", "", "ecommerce");
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Insert order
$sql = "INSERT INTO orders (user_id, name, address, payment_method, total_price, order_date, mobile, payment_status) 
        VALUES (?, ?, ?, ?, ?, NOW(), ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isssdss", $user_id, $name, $address, $payment_method, $total_price, $mobile, $payment_status);
$stmt->execute();
$order_id = $stmt->insert_id;

// ✅ **Ensure the update happens only if payment is successful**
if ($payment_status == "SUCCESS") {
    $update_sql = "UPDATE orders SET payment_status = 'SUCCESS' WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("i", $order_id);
    $update_stmt->execute();
    unset($_SESSION['checkout']);
    header("Location: order_success.php");
    exit();
} else {
    header("Location: payment_failed.php");
    exit();
}
?>
