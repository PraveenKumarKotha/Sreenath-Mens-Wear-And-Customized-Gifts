<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['checkout'])) {
    header("Location: checkout.php");
    exit();
}

$checkout_data = $_SESSION['checkout'];
$payment_method = $checkout_data['payment_method'];
$total_price = number_format($checkout_data['total_price'], 2, '.', '');

// Set UPI ID based on Payment Method
$upi_id = "";
$merchant_name = "MyEcommerceStore";

switch (($payment_method)) {
    case "Google Pay":
        $upi_id = "7981694030-2@axl"; // Replace with your actual UPI ID
        break;
    case "Phonepe":
        $upi_id = "7981694030-2@axl"; // Replace with your actual UPI ID
        break;
    case "Paytm":
        $upi_id = "7981694030-2@axl"; // Replace with your actual UPI ID
        break;
    case "Amazon Pay":
        $upi_id = "7981694030-2@axl"; // Replace with your actual UPI ID
        break;    
    default:
        echo "<script>alert('Invalid payment method selected!'); window.location.href='checkout.php';</script>";
        exit();
}

// Generate UPI Payment URL (Properly Encoded)
$upi_url = "upi://pay?pa=" . urlencode($upi_id) .
           "&pn=" . urlencode($merchant_name) .
           "&mc=" .
           "&tid=" .
           "&tr=" .
           "&tn=" . urlencode("Payment for Order") .
           "&am=" . urlencode($total_price) .
           "&cu=INR";

// Generate QR Code using QRServer API
$qr_code_url = "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=" . urlencode($upi_url);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f8fff8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            text-align: center;
            max-width: 400px;
        }
        h1 {
            color: #28a745;
        }
        .total {
            font-size: 22px;
            font-weight: bold;
            margin: 20px 0;
        }
        .qr-code {
            margin: 20px 0;
        }
        .pay-btn {
            background: #28a745;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            font-size: 18px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin-top: 15px;
        }
        .pay-btn:hover {
            background: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Scan to Pay</h1>
        <p>Payment Method: <strong><?= htmlspecialchars($payment_method) ?></strong></p>
        <p class="total">Total: Rs.<?= $total_price ?></p>

        <!-- QR Code for UPI Payment -->
        <div class="qr-code">
            <img src="<?= $qr_code_url ?>" alt="UPI QR Code">
        </div>

        <p>Scan the QR code with your UPI app to complete the payment.</p>

        <!-- Button to Confirm Payment -->
        <form action="verify_payment.php" method="post">
            <input type="hidden" name="transaction_id" id="transaction_id">
            <button type="submit" class="pay-btn">I Have Paid</button>
        </form>
    </div>

    <script>
        document.querySelector("form").addEventListener("submit", function(event) {
            let transactionId = prompt("Enter the UPI Transaction ID received after payment:");
            if (!transactionId) {
                alert("Transaction ID is required to confirm payment.");
                event.preventDefault(); // Stop form submission
            } else {
                document.getElementById("transaction_id").value = transactionId;
            }
        });
    </script>
</body>
</html>
