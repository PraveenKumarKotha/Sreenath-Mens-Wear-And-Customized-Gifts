<?php
include('../includes/db.php');

$success_message = "";
$error_message = "";

// If reset link is visited
if (isset($_GET['email']) && isset($_GET['token'])) {
    $email = $_GET['email'];
    $token = $_GET['token'];

    // Validate token and expiration
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND reset_token = ?");
    $stmt->execute([$email, $token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || strtotime($user['reset_expires']) < time()) {
        $error_message = "Invalid or expired token.";
    }

    // If form submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'], $_POST['confirm_password'])) {
        if ($_POST['password'] !== $_POST['confirm_password']) {
            $error_message = "Passwords do not match.";
        } else {
            $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

            // Update password, clear token
            $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE email = ?");
            $stmt->execute([$new_password, $email]);

            $success_message = "
                ✅ <strong>Password reset successful!</strong><br><br>
                <a href='login.php' style='
                    display: inline-block;
                    padding: 10px 20px;
                    background-color: #28a745;
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                    font-weight: bold;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                    transition: background-color 0.3s ease;
                ' onmouseover=\"this.style.backgroundColor='#218838'\"
                   onmouseout=\"this.style.backgroundColor='#28a745'\">
                    Login Now
                </a>
            ";
        }
    }
} else {
    $error_message = "Invalid request!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .reset-container {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        .reset-container h2 {
            margin-bottom: 20px;
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .input-group {
            position: relative;
            width: 100%;
        }
        input[type="password"],
        input[type="text"] {
            width: 100%;
            padding: 10px 35px 10px 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 1em;
        }
        .toggle-password {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 16px;
            color: #555;
            user-select: none;
        }
        button {
            margin-top: 15px;
            padding: 10px;
            width: 100%;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 15px;
            font-size: 1em;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
<div class="reset-container">
    <h2>Reset Password</h2>

    <?php if ($error_message): ?>
        <p class="message error"><?= htmlspecialchars($error_message) ?></p>
    <?php elseif ($success_message): ?>
        <p class="message"><?= $success_message ?></p>
    <?php else: ?>
        <form method="POST">
            <label>New Password:</label>
            <div class="input-group">
                <input type="password" id="password" name="password" required>
                <span class="toggle-password" onclick="togglePassword('password', this)">👁️</span>
            </div>

            <label>Confirm Password:</label>
            <div class="input-group">
                <input type="password" id="confirm_password" name="confirm_password" required>
                <span class="toggle-password" onclick="togglePassword('confirm_password', this)">👁️</span>
            </div>

            <button type="submit">Update Password</button>
        </form>
    <?php endif; ?>
</div>

<script>
function togglePassword(id, el) {
    const input = document.getElementById(id);
    if (input.type === "password") {
        input.type = "text";
        el.textContent = "🙈";
    } else {
        input.type = "password";
        el.textContent = "👁️";
    }
}
</script>
</body>
</html>
