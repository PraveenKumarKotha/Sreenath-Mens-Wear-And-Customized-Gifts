<?php
include('../includes/db.php');
require '../includes/phpmailer/PHPMailer.php';
require '../includes/phpmailer/SMTP.php';
require '../includes/phpmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


$success_message = "";
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    // Check if email exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Generate token
        $token = bin2hex(random_bytes(32));
        $expires = date("Y-m-d H:i:s", strtotime("+1 hour"));

        // Save token and expiry to DB
        $stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?");
        $stmt->execute([$token, $expires, $email]);

        // Send reset link
        $reset_link = "https://sreenathmenswearandcustomizedgifts.fwh.is/pages/reset_password.php?email=" . urlencode($email) . "&token=" . urlencode($token);

        $mail = new PHPMailer(true);
        try {
            // SMTP settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';  
            $mail->SMTPAuth = true;
            $mail->Username = 'sreenathmenswear7@gmail.com'; 
            $mail->Password = 'vdew lvzm qvte pdim';     
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            // Email content
            $mail->setFrom('sreenathmenswear7@gmail.com', 'Sreenath Mens Wear and Customized Gifts');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset Request';
            $mail->Body = "Click this link to reset your password: <a href='$reset_link'>Reset Password</a>";

            $mail->send();
            $success_message = 'Password reset link has been sent to your email. Please check your <strong style="color:black;">Inbox</strong> or <strong style="color:black;">Spam folder</strong> and click the verification link to activate your account.';
        } catch (Exception $e) {
            $error_message = "Email could not be sent. Error: " . $mail->ErrorInfo;
        }
    } else {
        $error_message = "Email not found in our records.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            width: 400px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
        }
        button {
            padding: 10px;
            width: 100%;
            background-color: green;
            color: white;
            border: none;
            margin-top: 15px;
            cursor: pointer;
        }
        .message {
            margin-top: 10px;
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Forgot Password</h2>
    <form method="POST">
        <label>Enter your registered email:</label>
        <input type="email" name="email" required>
        <button type="submit">Send Reset Link</button>
    </form>
    <?php if ($success_message): ?>
        <p class="message"><?= $success_message ?></p>
    <?php elseif ($error_message): ?>
        <p class="message error"><?= $error_message ?></p>
    <?php endif; ?>
</div>
</body>
</html>
