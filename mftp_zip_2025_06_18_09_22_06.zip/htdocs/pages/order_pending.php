<?php
session_start();
include '../includes/db.php'; // Ensure correct path

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch pending payments for the logged-in user from the payments table
$stmt = $conn->prepare("SELECT * FROM payments WHERE user_id = ? AND status = 'PENDING' ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$pending_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch approved payments (SUCCESS)
$stmt = $conn->prepare("SELECT * FROM payments WHERE user_id = ? AND status = 'SUCCESS' ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$approved_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch failed payments (FAILED)
$stmt = $conn->prepare("SELECT * FROM payments WHERE user_id = ? AND status = 'FAILED' ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$failed_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Check if there are any payments in any category
$hasPending = count($pending_payments) > 0;
$hasApproved = count($approved_payments) > 0;
$hasFailed = count($failed_payments) > 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Payment Status</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #fafafa;
            color: #333;
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
        }
        h2 {
            text-align: center;
            color: #3d3d3d;
            font-size: 36px;
            margin-bottom: 20px;
        }
        .payment-section {
            margin-bottom: 30px;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .payment-section h3 {
            font-size: 28px;
            color: #555;
            margin-bottom: 15px;
        }
        .payment-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            overflow-x: auto;
        }
        .payment-table th, .payment-table td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
            font-size: 16px;
        }
        .payment-table th {
            background-color: #f2f2f2;
            color: #555;
        }
        .payment-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .pending {
            background-color: #ffecb3;
            color: #ff5722;
            border-left: 5px solid #ff5722;
        }
        .success {
            background-color: #c8e6c9;
            color: #388e3c;
            border-left: 5px solid #388e3c;
        }
        .failed {
            background-color: #ffccd5;
            color: #e91e63;
            border-left: 5px solid #e91e63;
        }
        .payment-table a {
            color: #1976d2;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .payment-table a:hover {
            color: #0d47a1;
        }
        .back-to-home {
            text-align: center;
            margin-top: 30px;
        }
        .back-to-home a {
            color: #1e88e5;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .back-to-home a:hover {
            color: #1565c0;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            .payment-table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
            h2 {
                font-size: 28px;
            }
            .payment-section h3 {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Order Payment Status</h2>

    <?php if ($hasPending): ?>
    <div class="payment-section pending">
        <h3>Your Pending Payments</h3>
        <table class="payment-table">
            <tr>
                <th>Transaction ID</th>
                <th>Order ID</th>
                <th>Amount</th>
                <th>Payment Method</th>
                <th>Status</th>
            </tr>
            <?php foreach ($pending_payments as $payment): ?>
            <tr>
                <td><?php echo $payment['transaction_id']; ?></td>
                <td><?php echo $payment['order_id'] ?? 'N/A'; ?></td>
                <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                <td><?php echo $payment['payment_method']; ?></td>
                <td>🔄 Awaiting Admin Approval</td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php endif; ?>

    <?php if ($hasApproved): ?>
    <div class="payment-section success">
        <h3>Your Approved Payments</h3>
        <table class="payment-table">
            <tr>
                <th>Transaction ID</th>
                <th>Order ID</th>
                <th>Amount</th>
                <th>Payment Method</th>
                <th>Action</th>
            </tr>
            <?php foreach ($approved_payments as $payment): ?>
            <tr>
                <td><?php echo $payment['transaction_id']; ?></td>
                <td><?php echo $payment['order_id'] ?? 'N/A'; ?></td>
                <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                <td><?php echo $payment['payment_method']; ?></td>
                <td>
                    <a href="order_success.php?transaction_id=<?php echo $payment['transaction_id']; ?>&order_id=<?php echo $payment['order_id']; ?>">
                        View Order
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php endif; ?>

    <?php if ($hasFailed): ?>
    <div class="payment-section failed">
        <h3>Your Failed Payments</h3>
        <table class="payment-table">
            <tr>
                <th>Transaction ID</th>
                <th>Order ID</th>
                <th>Amount</th>
                <th>Payment Method</th>
                <th>Action</th>
            </tr>
            <?php foreach ($failed_payments as $payment): ?>
            <tr>
                <td><?php echo $payment['transaction_id']; ?></td>
                <td><?php echo $payment['order_id'] ?? 'N/A'; ?></td>
                <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                <td><?php echo $payment['payment_method']; ?></td>
                <td>
                    <a href="payment_failed.php?transaction_id=<?php echo $payment['transaction_id']; ?>">
                        Retry Payment
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php endif; ?>

    <div class="back-to-home">
        <a href="../index.php">Back to Home</a>
    </div>
</div>

</body>
</html>
