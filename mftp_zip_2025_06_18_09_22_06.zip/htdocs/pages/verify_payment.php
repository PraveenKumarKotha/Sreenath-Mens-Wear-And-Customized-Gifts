<?php
session_start();
include($_SERVER['DOCUMENT_ROOT'] . "/includes/db.php");
if (!isset($_SESSION['user_id']) || !isset($_SESSION['checkout'])) {
    die("❌ User ID or Checkout data not found. Check session variables.");
}

$user_id = $_SESSION['user_id'];
$checkout_data = $_SESSION['checkout'];
$transaction_id = $_POST['transaction_id'] ?? null;

if (!$transaction_id) {
    die("❌ No transaction ID provided. Please check your payment process.");
}

try {
    // Check if the transaction ID already exists
    $check_stmt = $conn->prepare("SELECT id FROM payments WHERE transaction_id = :transaction_id");
    $check_stmt->execute(['transaction_id' => $transaction_id]);
    $existing_payment = $check_stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_payment) {
        die("❌ Transaction ID already exists. Payment might be duplicated.");
    }

    // 🔥 Manual verification required
    $payment_verified = false; // Default: Not verified

    // Get product IDs, quantities, and sizes from the cart
    $products_data = [];

    foreach ($checkout_data['cart_items'] as $item) {
        $products_data[] = [
            "id" => $item['product_id'],
            "qty" => $item['quantity'],
            "size" => $item['size'] ?? 'N/A' // Ensure size is stored
        ];
    }

    $product_json = json_encode($products_data); // Convert to JSON format

    // Insert order with status "PENDING APPROVAL"
    $insert_order = $conn->prepare("INSERT INTO orders (user_id, name, address, payment, payment_method, total_price, payment_status, order_date, mobile, payment_reference, product_ids) 
    VALUES (:user_id, :name, :address, 'PENDING APPROVAL', :payment_method, :total_price, 'PENDING', NOW(), :mobile, :transaction_id, :product_ids)");

    $insert_order->execute([
        'user_id' => $user_id,
        'name' => $checkout_data['name'],
        'address' => $checkout_data['address'],
        'payment_method' => $checkout_data['payment_method'],
        'total_price' => $checkout_data['total_price'],
        'mobile' => $checkout_data['mobile'],
        'transaction_id' => $transaction_id,
        'product_ids' => $product_json // Store product IDs + quantities + size in JSON format
    ]);

    $order_id = $conn->lastInsertId(); // Get newly created order ID

    // Insert payment details but mark as 'PENDING'
    $insert_payment = $conn->prepare("INSERT INTO payments (user_id, order_id, transaction_id, amount, payment_method, status) 
    VALUES (:user_id, :order_id, :transaction_id, :amount, :payment_method, 'PENDING')");

    $insert_payment->execute([
        'user_id' => $user_id,
        'order_id' => $order_id,
        'transaction_id' => $transaction_id,
        'amount' => $checkout_data['total_price'],
        'payment_method' => $checkout_data['payment_method']
    ]);

    // ✅ Clear session and user's cart
    unset($_SESSION['checkout']);
    $delete_cart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $delete_cart->execute([$user_id]);

    // ✅ Redirect to a page saying "Order Pending Verification"
    $_SESSION['payment_status'] = "PENDING";
    header("Location: order_pending.php"); // Create this page
    exit();
} catch (PDOException $e) {
    die("❌ Database Error: " . $e->getMessage());
}
?>
