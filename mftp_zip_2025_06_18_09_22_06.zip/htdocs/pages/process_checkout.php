<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user_id'];
    $name = trim($_POST['name']);
    $address = trim($_POST['address']);
    $mobile = trim($_POST['mobile']);
    $payment_method = $_POST['payment'];

    // Validate Mobile Number (10 digits)
    if (!preg_match("/^[0-9]{10}$/", $mobile)) {
        die("Invalid mobile number. Please enter a 10-digit number.");
    }

    // Fetch cart items (including size)
    $stmt = $conn->prepare("SELECT c.product_id, c.quantity, p.price, p.image, c.size 
                            FROM cart c 
                            JOIN products p ON c.product_id = p.id 
                            WHERE c.user_id = ?");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($cart_items)) {
        die("Your cart is empty. <a href='cart.php'>Go back to cart</a>");
    }

    // Calculate total price and prepare products array
    $total_price = 0;
    $products = [];  

    foreach ($cart_items as $item) {
        $size = !empty($item['size']) ? $item['size'] : 'N/A';
        $products[] = [
            'id' => $item['product_id'],
            'qty' => $item['quantity'],
            'size' => $size
        ];
        $total_price += $item['price'] * $item['quantity'];
    }

    // Store order details temporarily in session for payment processing
    $_SESSION['checkout'] = [
        'name' => $name,
        'address' => $address,
        'mobile' => $mobile,
        'payment_method' => $payment_method,
        'total_price' => $total_price,
        'cart_items' => $cart_items
    ];

    // Redirect to payment page
    header("Location: payment.php");
    exit();
} else {
    header("Location: checkout.php");
    exit();
}
