<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

$user_id = $_SESSION['user_id'];

// Fetch cart items with product details including size
$stmt = $conn->prepare("SELECT c.product_id, c.quantity, p.name, p.price, p.image, c.size 
                        FROM cart c 
                        JOIN products p ON c.product_id = p.id 
                        WHERE c.user_id = ?");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total price
$total_price = 0;
foreach ($cart_items as $item) {
    $total_price += $item['price'] * $item['quantity'];
}

// If cart is empty, show message
if (empty($cart_items)) {
    echo "
    <html>
    <head>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Empty Cart? Seriously?!</title>
        <style>
            body {
                font-family: 'Comic Sans MS', cursive, sans-serif;
                background: linear-gradient(135deg, #ff9a9e, #fad0c4);
                text-align: center;
                color: white;
                padding: 50px;
                overflow: hidden;
            }
            .empty-cart {
                font-size: 26px;
                font-weight: bold;
                margin-top: 50px;
                animation: shake 0.5s infinite alternate;
            }
            @keyframes shake {
                0% { transform: rotate(-3deg); }
                100% { transform: rotate(3deg); }
            }
            .emoji {
                font-size: 70px;
                display: block;
                margin-bottom: 20px;
            }
            .btn {
                display: inline-block;
                margin-top: 20px;
                padding: 12px 24px;
                background: #ff4757;
                color: white;
                text-decoration: none;
                border-radius: 12px;
                font-size: 20px;
                font-weight: bold;
                transition: 0.3s ease-in-out;
                box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
            }
            .btn:hover {
                background: #e84118;
                transform: scale(1.1);
            }
            .dancing-emoji {
                display: inline-block;
                animation: dance 1s infinite;
            }
            @keyframes dance {
                0% { transform: rotate(0deg); }
                25% { transform: rotate(-10deg); }
                50% { transform: rotate(10deg); }
                75% { transform: rotate(-10deg); }
                100% { transform: rotate(0deg); }
            }
            .floating-text {
                position: absolute;
                top: 10%;
                left: 50%;
                transform: translate(-50%, -50%);
                font-size: 20px;
                font-weight: bold;
                color: yellow;
                animation: float 3s infinite alternate ease-in-out;
            }
            @keyframes float {
                0% { top: 10%; }
                100% { top: 20%; }
            }
        </style>
    </head>
    <body>
        <div class='floating-text'>Your cart is crying... 😭</div>
        <div class='empty-cart'>
            <span class='emoji dancing-emoji'>🛒💨</span><br>
            Whoa! Your cart is faster than Flash—it disappeared!<br>
            Even a desert has more items than your cart. 🌵😂<br>
            <a href='cart.php' class='btn'>🛍️ Go Fill It Up!</a>
        </div>
    </body>
    </html>";
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        /* 🌿 Beautiful Background - Light & Elegant */
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(to bottom, #ecfdf5, #ffffff);
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start; /* Changed from center to allow content growth */
            min-height: 100vh; /* Allows scrolling when content overflows */
            overflow-y: auto; /* Enables vertical scrolling */
        }

        /* 🛍️ Checkout Container - Elegant & Rounded */
        .container {
            width: 90%;
            max-width: 600px;
            background: white;
            padding: 30px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            border-radius: 14px;
            text-align: center;
            margin-top: 20px; /* Added margin to avoid sticking at the top */
        }

        /* ✨ Stunning Checkout Heading */
        .checkout-heading {
            background: linear-gradient(to right, #5cb85c, #81c784);
            color: white;
            padding: 15px;
            font-size: 28px;
            font-weight: bold;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            margin-bottom: 15px;
            font-family: 'Arial Black', sans-serif;
            letter-spacing: 1px;
            text-shadow: 2px 2px 8px rgba(255, 255, 255, 0.3);
        }

        h2 {
            font-size: 22px;
            color: #444;
            margin-bottom: 10px;
        }

        /* 🛒 Cart Items - Clean & Minimal */
        .cart-items {
            list-style: none;
            padding: 0;
            text-align: left;
        }

        .cart-item {
            display: flex;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding: 12px 0;
        }

        .cart-item img {
            width: 70px;
            height: 70px;
            border-radius: 8px;
            margin-right: 15px;
        }

        .item-details {
            flex-grow: 1;
        }

        .item-name {
            font-size: 1.1em;
            font-weight: bold;
            color: #333;
        }

        .item-price {
            font-size: 1em;
            color: #666;
        }

        .item-size {
            font-size: 0.9em;
            color: #888;
        }

        /* 💲 Total Price Styling */
        .total {
            font-size: 1.5em;
            font-weight: bold;
            color: #4CAF50;
            margin-top: 20px;
        }

        /* 📝 Form - Improved Input Styling */
        form {
            display: flex;
            flex-direction: column;
            gap: 14px;
            text-align: left;
        }

        label {
            font-weight: bold;
            color: #333;
        }

        input, textarea, select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            width: 100%;
            font-size: 16px;
            transition: 0.3s;
            background: #f9dfb;
        }

        input:focus, textarea:focus, select:focus {
            border-color: #4CAF50;
            outline: none;
            box-shadow: 0px 0px 6px rgba(76, 175, 80, 0.4);
        }

        /* 📱 Mobile Number Field Restriction */
        input#mobile {
            background: #f9fff8;
        }

        input#mobile:invalid {
            border-color: red;
        }

        /* 🛒 Checkout Button - Modern & Attractive */
        button {
            background: linear-gradient(to right, #4CAF50, #66bb6a);
            color: white;
            padding: 12px;
            border: none;
            cursor: pointer;
            font-size: 1.1em;
            border-radius: 8px;
            transition: 0.3s;
            font-weight: bold;
        }

        button:hover {
            background: linear-gradient(to right, #388E3C, #43a047);
            box-shadow: 0px 4px 10px rgba(76, 175, 80, 0.4);
        }

    </style>
</head>
<body>
    <div class="container">
        <h1 class="checkout-heading">🛒 Secure Checkout</h1>
        
        <h2>Your Cart</h2>
        <ul class="cart-items">
            <?php foreach ($cart_items as $item): ?>
                <li class="cart-item">
                    <img src="../images/<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                    <div class="item-details">
                        <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
                        <div class="item-price">Quantity: <?= $item['quantity'] ?> - Price: Rs.<?= number_format($item['price'], 2) ?></div>
                        <div class="item-size">Size: <?= htmlspecialchars($item['size']) ?></div>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
        <p class="total">Total Price: Rs.<?= number_format($total_price, 2) ?></p>

        <h2>Customer Information</h2>
        <form action="process_checkout.php" method="post">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" placeholder="Enter your name" required>
            
            <label for="address">Delivery Address:</label>
            <textarea id="address" name="address" placeholder="Enter your full address" required></textarea>

            <label for="mobile">Mobile Number:</label>
            <input type="tel" id="mobile" name="mobile" pattern="[0-9]{10}" 
                   placeholder="Enter 10-digit mobile number" 
                   maxlength="10" required 
                   oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);">

            <label for="payment">Payment Method:</label>
            <select id="payment" name="payment" required>
                <option value="Phonepe">PhonePe</option>
                <option value="Google Pay">Google Pay</option>
                <option value="Paytm">Paytm</option>
                <option value="Amazon Pay">Amazon Pay</option>
            </select>
            
            <button type="submit">✅ Place Order</button>
        </form>
    </div>
</body>
</html>
