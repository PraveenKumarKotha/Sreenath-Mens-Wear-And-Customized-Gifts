<?php
session_start();
include 'db_connection.php'; // Ensure this file connects to your database

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Find the most recent order for the logged-in user
$sql = "SELECT id, payment_status FROM orders WHERE user_id = ? ORDER BY order_date DESC LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

if ($order) {
    $order_id = $order['id'];
    $payment_status = $order['payment_status'];

    if ($payment_status === 'PENDING') {
        // Update payment status to SUCCESS
        $update_sql = "UPDATE orders SET payment_status = 'SUCCESS' WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("i", $order_id);
        if ($update_stmt->execute()) {
            // Redirect to Order Success Page
            header("Location: order_success.php");
            exit();
        } else {
            echo "Error updating payment status. Please try again.";
        }
    } else {
        // Already marked as SUCCESS
        header("Location: order_success.php");
        exit();
    }
} else {
    echo "No recent order found!";
}
?>
