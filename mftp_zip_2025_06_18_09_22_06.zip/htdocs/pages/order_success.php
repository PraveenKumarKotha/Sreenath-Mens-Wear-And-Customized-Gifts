<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';

// Get the order_id from the URL (if available)
$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : null;

// Check if order_id is provided
if (!$order_id) {
    echo "<script>alert('Order ID is missing!'); window.location.href = '../index.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch the order details based on order_id and user_id
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $user_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

// If no order found, redirect to homepage
if (!$order) {
    echo "<script>alert('Order not found or you do not have access to this order!'); window.location.href = '../index.php';</script>";
    exit();
}

// Extract product details (IDs, quantities, sizes) from JSON format
$products_data = json_decode($order['product_ids'], true); // Convert JSON to array

// Fetch product details for the ordered products
$products = [];
if (!empty($products_data)) {
    $product_ids = array_column($products_data, 'id'); // Extract only product IDs
    $placeholders = implode(',', array_fill(0, count($product_ids), '?')); // Create placeholders for IN clause
    
    $stmt = $conn->prepare("SELECT id, name, price, image FROM products WHERE id IN ($placeholders)");
    $stmt->execute($product_ids);
    $fetched_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Map quantities and sizes to the products
    foreach ($fetched_products as $product) {
        foreach ($products_data as $p_data) {
            if ($p_data['id'] == $product['id']) {
                $product['quantity'] = $p_data['qty']; // Assign quantity to product
                $product['size'] = isset($p_data['size']) ? $p_data['size'] : 'N/A'; // Assign size or default to 'N/A'
                $products[] = $product;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎉 Order Successful</title>
    <style>
        html, body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(to bottom, #e3f9e5, #ffffff);
            color: #333;
            margin: 0;
            padding: 0;
            height: 100%;
            overflow-y: auto;
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 90%;
            text-align: center;
            margin: 20px auto;
            animation: fadeIn 0.8s ease-in-out;
        }

        .success-heading {
            background: linear-gradient(to right, #4CAF50, #66bb6a);
            color: white;
            padding: 15px;
            font-size: 26px;
            font-weight: bold;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
        }

        .order-details {
            text-align: left;
            font-size: 18px;
            background: #f9fff8;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .order-items {
            list-style: none;
            padding: 0;
            max-height: 300px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            margin-top: 10px;
        }

        .order-item {
            display: flex;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }

        .order-item img {
            width: 60px;
            height: 60px;
            border-radius: 8px;
            margin-right: 15px;
        }

        .back-home {
            display: inline-block;
            padding: 12px 20px;
            background: linear-gradient(to right, #4CAF50, #66bb6a);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 16px;
            font-weight: bold;
            transition: 0.3s;
        }

        .back-home:hover {
            background: linear-gradient(to right, #388E3C, #43a047);
            box-shadow: 0px 4px 10px rgba(76, 175, 80, 0.4);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="success-heading">🎉 Order Placed Successfully!</h1>
        <p>Thank you for shopping with us. Your order has been placed successfully.</p>
        <p>Delivery details will be Sent to Your Whatsapp.</p>
        <div class="order-details">
            <p><strong>📦 Order ID:</strong> <?= htmlspecialchars($order['id']); ?></p>
            <p><strong>💰 Total Price:</strong> ₹<?= number_format($order['total_price'], 2); ?></p>
            <p><strong>📞 Mobile:</strong> <?= htmlspecialchars($order['mobile']); ?></p>
            <p><strong>🏠 Address:</strong> <?= htmlspecialchars($order['address']); ?></p>
            <p><strong>💳 Payment Method:</strong> <?= strtoupper($order['payment_method']); ?></p>
            <p><strong>📅 Order Date:</strong> <?= $order['order_date']; ?></p>

            <h3>🛍️ Ordered Items:</h3>
            <ul class="order-items">
                <?php foreach ($products as $product): ?>
                    <li class="order-item">
                        <img src="../images/<?= htmlspecialchars($product['image']); ?>" alt="<?= htmlspecialchars($product['name']); ?>">
                        <span><?= htmlspecialchars($product['name']); ?> - ₹<?= number_format($product['price'], 2); ?> 
                        <strong>(Qty: <?= $product['quantity']; ?> | Size: <?= htmlspecialchars($product['size']); ?>)</strong></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <a href="../index.php" class="back-home">🛍️ Continue Shopping</a>
    </div>
</body>
</html>