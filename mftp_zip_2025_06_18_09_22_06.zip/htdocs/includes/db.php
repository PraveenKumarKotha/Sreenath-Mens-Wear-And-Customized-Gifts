<?php
$host = 'sql109.infinityfree.com';
$dbname = 'if0_38605433_ecommerce';
$user = 'if0_38605433';
$password = 'sreenath777';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
